import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

/*
 * use array list for appointment service
 */

public class AppointmentService {
  final private List<Appointment> appointmentList = new ArrayList<>();
  
  /*
   * create a method to create a new ID
   * use randomUUID to create a unique ID
   * limit to the possible length
   */

  private String newUniqueId() {
    return UUID.randomUUID().toString().substring(
        0, Math.min(toString().length(), 10));
  }

  /*
   * create method for adding new appointment 
   */

  public void newAppointment(Date date, String description) {
    Appointment appt = new Appointment(newUniqueId(), date, description);
    appointmentList.add(appt);
  }
  
  /*
   * create method for deleting appointment
   */

  public void deleteAppointment(String id) throws Exception {
    appointmentList.remove(searchForAppointment(id));
  }
  
  /*
   * create method to add appointment to list
   * create condition for appointment not in database
   */

  protected List<Appointment> getAppointmentList() { return appointmentList; }

  private Appointment searchForAppointment(String id) throws Exception {
    int index = 0;
    while (index < appointmentList.size()) {
      if (id.equals(appointmentList.get(index).getAppointmentId())) {
        return appointmentList.get(index);
      }
      index++;
    }
    throw new Exception("The appointment does not exist!");
  }
}