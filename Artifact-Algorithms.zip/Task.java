import java.util.Comparator;


public class Task {
	/*
	 * create private variables
	 */
	
	private String id;
	private String name;
	private String description;
	
	
	/*
	 * create public constructor for task
	 */
	
	public Task(String id, String name, String description) {
		this.id = id;
		this.name = name;
		this.description = description;
	}
	
	/*
	 * create getter and setter for the variable id
	 */
	
	public String getId() {
		return id;
	}
	
	public void setId(String id) {
		this.id = id;
	}
	
	/*
	 * create getter and setter for variable name
	 */
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	/*
	 * Create getter and setter for description
	 */
	public String getDescription() {
		return description;
	}
	
	public void setDescription(String description) {
		this.description = description;
	}
	
	/*
	 * create parameters for task objects
	 * false if task is null
	 */
	@Override
	public boolean equals(Object obj) {
		if(this == obj)
			return false;
		if(obj == null)
			return false;
		if(this.getClass() != obj.getClass())
			return false;
		Task t = (Task) obj;
		return getId().equals(t.getId());
	
	/*
	 * use Comparator interface
	 * we will compare id variables of different tasks
	 * this will help validate that tasks will not update
	 */
	
	public static Comparator;<Task> compareById = new Comparator <Task>() {
		@Override
		public int compare(Task t1, Task t2) {
			return t1.getId().compareTo(t2.getId());
		}
	};
	}
	
	/*
	 * To see what we are working with we will print the string of the object
	 * this will display id, name, and description
	 * add new line for readability
	 */
	
	@Override
	public String toString() {
		return "Task ID: " + getId() + "\nName: " + getName() + "\nDescription: " + getDescription() +"\n";
	
	}

	public void addTask(Task task) {
		// TODO Auto-generated method stub
		
	}
}
