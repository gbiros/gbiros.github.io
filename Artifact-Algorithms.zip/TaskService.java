import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class TaskService {

	/*
	 * create an array list so we can save multiple tasks
	 */
	
	public static List<Task>tasks = new ArrayList<>();
	public static void main(String[] args) {
		
		
		/*
		 * create an object for task service
		 */
		
		TaskService service = new TaskService();
		
		/*We will add tasks before the Junit tests to ensure the
		 *add, delete, and update functions
		 *
         *
         */
		//use the addTask method to store tasks in the service variable
		//create three valid tasks
		//each task should have an id, name, and a description

		service.addTask(new Task("0000000001", "Riding", "Ride a Horse"));
		service.addTask(new Task("0000000002", "Playing", "Play the Guitar"));
		service.addTask(new Task("0000000003", "Sleeping", "Take a Nap"));

		//to validate we will print the newly added tasks to variable service.
		for (Task obj : tasks) {
		System.out.println(obj);
		}

		//create an existing task ID
		//exiating Id should not take due to the existing Id number occupied

		service.addTask(new Task("0000000001", "Riding", "Riding a Roller Coaster"));
		System.out.println("Delete Task ID #0000000002");
		service.deleteTask("0000000002");
		System.out.println("Update Task ID #0000000003");
		service.update(new Task("0000000003", "Jumping", "Jumping Rope"));


		//display all added and updated Task object
		//this will validate the add, delete, and update functions
		//print new line
		for (Task obj : tasks) {
		System.out.println(obj);
		}
		}


		/**
		*add tasks if they meet the requirements
		*/
		public boolean addTask(Task task) {

		//use Collections binary search to check if the ID already exists
		//return negative integers if the ID is not found
		int index = getIndex(task);


		//validate id if doesn't exist, name & description
		if (index < 0 && validateID(task.getId()) && validateName(task.getName()) && validateDescription(task.getDescription())) {
		tasks.add(task);
		return true;
		}
		return false;
		}


		/**
		* delete task if ID exists
		*/
		public void deleteTask(String id) {

		//invoke getIndex(Task) method
		//create new instance of Task object and pass the String ID in the constructor, set name and description as empty      or null
		//if ID found, return int value as List index (0...N)
		int index = getIndex(new Task(id, "", ""));

		//check if index is greater than or equal to 0 to prevent ArrayIndexOutOfBoundsException
		if (index >= 0)
		tasks.remove(index);
		}


		/*
		* if the ID value exists, update the name and description  
		*/

		public void update(Task task) {
		for (Task obj : tasks) {
		if (obj.equals(task) && validateName(task.getName()) && validateDescription(task.getDescription())) {
		obj.setName(task.getName());
		obj.setDescription(task.getDescription());
		}
		}
		}


		/**
		* use Collections binary search by Task ID
		* return positive integer if ID is found
		* return negative integer if ID is not found
		*/
		public int getIndex(Task task) {
		int index = Collections.binarySearch(tasks, task, Task.compareById);
		return index;
		}


		/**
		* 
		*requirement: Id cannot be more than 10 characters
		* validate the requirement is being met
		* 
		*/

		public boolean validateID(String id) {
		if (id != null && id.length() <= 10)
		return true;


		return false;
		}


		/**
		* 
		* 
		* requirement: the name cannot more than 20 characters 
		*/
		public boolean validateName(String name) {
		if (name != null && name.length() <= 20)
		return true;


		return false;
		}


		/**
		* 
		* @param description
		* @return true or false
		* 
		* validate description parameter, if not null and length is less than or equal to 50
		*/
		public boolean validateDescription(String description) {
		if (description != null && description.length() <= 50)
		return true;
	

		return false;
		}
		}

