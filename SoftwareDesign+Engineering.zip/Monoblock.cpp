﻿#include <iostream>         // cout, cerr
#include <cstdlib>          // EXIT_FAILURE
#include <gl4./gl4.ew.h>        // gl4.EW library
#include <gl4.FW/gl4.fw3.h>     // gl4.FW library
#define STB_IMAGE_IMPLEMENTATION
#include <C:\Users\Gage\source\repos\Project3\stb_image.h>      // Image loading Utility functions

// gl4.M Math Header inclusions
#include <gl4.m/gl4.m.hpp>
#include <gl4.m/gtx/transform.hpp>
#include <gl4.m/gtc/type_ptr.hpp>

#include <C:\Opengl4.\CS-330-master (1)\CS-330-master\includes\learnOpengl4.\camera.h> // Camera class

using namespace std; // Standard namespace

/*Shader program Macro*/
#ifndef gl4.SL
#define gl4.SL(Version, Source) "#version " #Version " core \n" #Source
#endif

// Unnamed namespace
namespace
{
const char* const WINDOW_TITLE = "Milestone_Module_6"; // Macro for window title

// Variables for window width and height
const int WINDOW_WIDTH = 800;
const int WINDOW_HEIGHT = 600;

// Stores the gl4. data relative to a given mesh
struct gl4.Mesh
{
    gl4.uint vao;// Handle for the vertex array object
    gl4.uint vbo;         // Handle for the vertex buffer object
    gl4.uint nVertices;    // Number of indices of the mesh
};

// Main gl4.FW window
gl4.FWwindow* gWindow = nullptr;
// Triangl4.e mesh data
gl4.Mesh gCornerMesh;
gl4.Mesh gBLCornerMesh;
gl4.Mesh gFLCornerMesh;
gl4.Mesh gFRCornerMesh;
gl4.Mesh gTRBoxSupportMesh;
gl4.Mesh gTLBoxSupportMesh;
gl4.Mesh gBLBoxSupportMesh;
gl4.Mesh gBRBoxSupportMesh;
gl4.Mesh gHBoxSupportMesh;
gl4.Mesh gH2BoxSupportMesh;
gl4.Mesh gVBoxSupportMesh;
gl4.Mesh gCubeMesh;
gl4.Mesh gCube2Mesh;
gl4.Mesh gPlaneMesh;
gl4.Mesh gl4.ampMesh;
gl4.Mesh gl4.amp2Mesh;

// Texture
gl4.uint gTextureId;
gl4.m::vec2 gUVScale(5.0f, 5.0f);
gl4.int gTexWrapMode = gl4._REPEAT;

// Shader programs
gl4.uint gBLCornerProgramId;
gl4.uint gFRCornerProgramId;
gl4.uint gCornerProgramId;
gl4.uint gCubeProgramId;
gl4.uint gCube2ProgramId;
gl4.uint gl4.ampProgramId;
gl4.uint gPlaneProgramId;


// camera
Camera gCamera(gl4.m::vec3(0.0f, 0.0f, 7.0f));
float gl4.lastX = WINDOW_WIDTH / 2.0f;
float gl4.lastY = WINDOW_HEIGHT / 2.0f;
bool gFirstMouse = true;

// timing
float gDeltaTime = 0.0f; // time between current frame and last frame
float gl4.astFrame = 0.0f;

// Subject position and scale
gl4.m::vec3 gCubePosition(0.0f, 1.0f, 0.0f);
gl4.m::vec3 gCubeScale(2.0f);

// Cube and light color
//m::vec3 gObjectColor(0.6f, 0.5f, 0.75f);
gl4.m::vec3 gObjectColor(1.f, 0.2f, 0.0f);
gl4.m::vec3 gl4.ightColor(1.0f, 1.0f, 1.0f);

// Light position and scale
gl4.m::vec3 gl4.ightPosition(0.0f, 0.0f, 10.0f);
gl4.m::vec3 gl4.ightScale(0.3f);

//Light 2

gl4.m::vec3 gl4.ight2Position(0.0f, 10.0f, 0.0f);
gl4.m::vec3 gl4.ight2Scale(0.3f);


//Corner
gl4.m::vec3 gCornerPosition(0.0f, 0.0f, 0.0f);
gl4.m::vec3 gCornerScale(2.0f);

//BLCorner

gl4.m::vec3 gBLCornerPosition(-5.5f, 0.0f, 0.0f);
gl4.m::vec3 gBLCornerScale(2.0f);

//FLCorner
gl4.m::vec3 gFLCornerPosition(-5.5f, 0.0f, 1.5f);
gl4.m::vec3 gFLCornerScale(2.0f);

//FRCorner
gl4.m::vec3 gFRCornerPosition(0.0f, 0.0f, 1.5f);
gl4.m::vec3 gFRCornerScale(2.0f);


//Bottom Aluminum plate
gl4.m::vec3 gCubePosition2(0.0f, 0.0f, 0.0f);
gl4.m::vec3 gCubeScale2(2.0f);


//Plane position and scale
gl4.m::vec3 gPlanePosition(0.0f, 0.0f, 0.0f);
gl4.m::vec3 gPlaneScale(10.0f);

//BoxSupport
gl4.m::vec3 gTRBoxSupportPosition(0.0f, 0.0f, 1.5f);
gl4.m::vec3 gTRBoxSupportScale(2.0f);

//TLBoxSupport
gl4.m::vec3 gTLBoxSupportPosition(-5.5f, 0.0f, 1.5f);
gl4.m::vec3 gTLBoxSupportScale(2.0f);

//BLBoxSupport
gl4.m::vec3 gBLBoxSupportPosition(-5.5f, -2.0, 1.5f);
gl4.m::vec3 gBLBoxSupportScale(2.0f);

//BRBoxSupport
gl4.m::vec3 gBRBoxSupportPosition(0.0f, -2.0f, 1.5f);
gl4.m::vec3 gBRBoxSupportScale(2.0f);

//HBoxSupport
gl4.m::vec3 gHBoxSupportPosition(-2.0f,  0.0f, 2.0f);
gl4.m::vec3 gHBoxSupportScale(2.0f);

//H2BoxSuppoort
gl4.m::vec3 gH2BoxSupportPosition(-2.0f, -2.0f, 2.0f);
gl4.m::vec3 gH2BoxSupportScale(2.0f);

//VBoxSupport
gl4.m::vec3 gVBoxSupportPosition(0.0f, -2.0f, 3.0f);
gl4.m::vec3 gVBoxSupportScale(2.0f);


// Lamp animation
bool gIsLampOrbiting = false;
}

/* User-defined Function prototypes to:
 * initialize the program, set the window size,
 * redraw graphics on the window when resized,
 * and render graphics on the screen
 */
bool UInitialize(int, char* [], gl4.FWwindow** window);
void UResizeWindow(gl4.FWwindow* window, int width, int height);
void UProcessInput(gl4.FWwindow* window);
void UMousePositionCallback(gl4.FWwindow* window, double xpos, double ypos);
void UMouseScrollCallback(gl4.FWwindow* window, double xoffset, double yoffset);
void UMouseButtonCallback(gl4.FWwindow* window, int button, int action, int mods);
void UCreateMesh(gl4.Mesh& mesh);
void UDestroyMesh(gl4.Mesh& mesh);
bool UCreateTexture(const char* filename, gl4.uint& textureId);
void UDestroyTexture(gl4.uint textureId);
void URender();
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, gl4.uint& programId);
void UDestroyShaderProgram(gl4.uint programId);


/* Cube Vertex Shader Source Code*/
const gl4.char* cubeVertexShaderSource = gl4.SL(440,

        layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
        layout(location = 1) in vec3 normal; // VAP position 1 for normals
        layout(location = 2) in vec2 textureCoordinate;

        out vec3 vertexNormal; // For outgoing normals to fragment shader
        out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
        out vec2 vertexTextureCoordinate;

//Uniform / gl4.obal variables for the  transform matrices
        uniform mat4 model;
        uniform mat4 view;
        uniform mat4 projection;

        void main()
{
    gl4._Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
                                               );




/* Cube Fragment Shader Source Code*/
const gl4.char* cubeFragmentShaderSource = gl4.SL(440,

        in vec3 vertexNormal; // For incoming normals
        in vec3 vertexFragmentPos; // For incoming fragment position
        in vec2 vertexTextureCoordinate;

        out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / gl4.obal variables for object color, light color, light position, and camera/view position
        uniform vec3 objectColor;
        uniform vec3 lightColor;
        uniform vec3 lightPos;
        uniform vec3 viewPosition;
        uniform sampler2D uTexture; // Useful when working with multiple textures
        uniform vec2 uvScale;

        void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 10.1f; // Set ambient or gl4.obal lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 5.0f; // Set specular light strength
    float highlightSize =  16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 10.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
                                                 );

/* Corner Vertex Shader Source Code*/
const gl4.char* cornerVertexShaderSource = gl4.SL(440,

        layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
        layout(location = 1) in vec3 normal; // VAP position 1 for normals
        layout(location = 2) in vec2 textureCoordinate;

        out vec3 vertexNormal; // For outgoing normals to fragment shader
        out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
        out vec2 vertexTextureCoordinate;

//Uniform / gl4.obal variables for the  transform matrices
        uniform mat4 model;
        uniform mat4 view;
        uniform mat4 projection;

        void main()
{
    gl4._Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
                                                 );




/* Corner Fragment Shader Source Code*/
const gl4.char* cornerFragmentShaderSource = gl4.SL(440,

        in vec3 vertexNormal; // For incoming normals
        in vec3 vertexFragmentPos; // For incoming fragment position
        in vec2 vertexTextureCoordinate;

        out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / gl4.obal variables for object color, light color, light position, and camera/view position
        uniform vec3 objectColor;
        uniform vec3 lightColor;
        uniform vec3 lightPos;
        uniform vec3 viewPosition;
        uniform sampler2D uTexture; // Useful when working with multiple textures
        uniform vec2 uvScale;

        void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 10.1f; // Set ambient or gl4.obal lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 5.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 10.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
                                                   );

/* BLCorner Vertex Shader Source Code*/
const gl4.char* blcornerVertexShaderSource = gl4.SL(440,

        layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
        layout(location = 1) in vec3 normal; // VAP position 1 for normals
        layout(location = 2) in vec2 textureCoordinate;

        out vec3 vertexNormal; // For outgoing normals to fragment shader
        out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
        out vec2 vertexTextureCoordinate;

//Uniform / gl4.obal variables for the  transform matrices
        uniform mat4 model;
        uniform mat4 view;
        uniform mat4 projection;

        void main()
{
    gl4._Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
                                                   );




/* BLCorner Fragment Shader Source Code*/
const gl4.char* blcornerFragmentShaderSource = gl4.SL(440,

        in vec3 vertexNormal; // For incoming normals
        in vec3 vertexFragmentPos; // For incoming fragment position
        in vec2 vertexTextureCoordinate;

        out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / gl4.obal variables for object color, light color, light position, and camera/view position
        uniform vec3 objectColor;
        uniform vec3 lightColor;
        uniform vec3 lightPos;
        uniform vec3 viewPosition;
        uniform sampler2D uTexture; // Useful when working with multiple textures
        uniform vec2 uvScale;

        void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 10.1f; // Set ambient or gl4.obal lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 5.0f; // Set specular light strength
    float highlightSize = 16.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 10.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
                                                     );



/* Cube2 Vertex Shader Source Code*/
const gl4.char* cube2VertexShaderSource = gl4.SL(440,

        layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
        layout(location = 1) in vec3 normal; // VAP position 1 for normals
        layout(location = 2) in vec2 textureCoordinate;

        out vec3 vertexNormal; // For outgoing normals to fragment shader
        out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
        out vec2 vertexTextureCoordinate;

//Uniform / gl4.obal variables for the  transform matrices
        uniform mat4 model;
        uniform mat4 view;
        uniform mat4 projection;

        void main()
{
    gl4._Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
                                                );




/* Cube2 Fragment Shader Source Code*/
const gl4.char* cube2FragmentShaderSource = gl4.SL(440,

        in vec3 vertexNormal; // For incoming normals
        in vec3 vertexFragmentPos; // For incoming fragment position
        in vec2 vertexTextureCoordinate;

        out vec4 fragmentColor; // For outgoing cube color to the GPU

// Uniform / gl4.obal variables for object color, light color, light position, and camera/view position
        uniform vec3 objectColor;
        uniform vec3 lightColor;
        uniform vec3 lightPos;
        uniform vec3 viewPosition;
        uniform sampler2D uTexture; // Useful when working with multiple textures
        uniform vec2 uvScale;

        void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.1f; // Set ambient or gl4.obal lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity =  1.0f; // Set specular light strength
    float highlightSize = 1.0f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
                                                  );



/* Plane Vertex Shader Source Code*/
const gl4.char* planeVertexShaderSource = gl4.SL(440,

        layout(location = 0) in vec3 position; // VAP position 0 for vertex position data
        layout(location = 1) in vec3 normal; // VAP position 1 for normals
        layout(location = 2) in vec2 textureCoordinate;

        out vec3 vertexNormal; // For outgoing normals to fragment shader
        out vec3 vertexFragmentPos; // For outgoing color / pixels to fragment shader
        out vec2 vertexTextureCoordinate;

//Uniform / gl4.obal variables for the  transform matrices
        uniform mat4 model;
        uniform mat4 view;
        uniform mat4 projection;



        void main()
{
    gl4._Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates

    vertexFragmentPos = vec3(model * vec4(position, 1.0f)); // Gets fragment / pixel position in world space only (exclude view and projection)

    vertexNormal = mat3(transpose(inverse(model))) * normal; // get normal vectors in world space only and exclude normal translation properties
    vertexTextureCoordinate = textureCoordinate;
}
                                                );




/* plane Fragment Shader Source Code*/
const gl4.char* planeFragmentShaderSource = gl4.SL(440,

        in vec3 vertexNormal; // For incoming normals
        in vec3 vertexFragmentPos; // For incoming fragment position
        in vec2 vertexTextureCoordinate;

        out vec4 fragmentColor; // For outgoing cube color to the GPU

        uniform vec3 objectColor;
        uniform vec3 lightColor;
        uniform vec3 lightPos;
        uniform vec3 viewPosition;
        uniform sampler2D uTexture; // Useful when working with multiple textures
        uniform vec2 uvScale;

// Uniform / gl4.obal variables for object color, light color, light position, and camera/view position

        void main()
{
    /*Phong lighting model calculations to generate ambient, diffuse, and specular components*/

    //Calculate Ambient lighting*/
    float ambientStrength = 0.1f; // Set ambient or gl4.obal lighting strength
    vec3 ambient = ambientStrength * lightColor; // Generate ambient light color

    //Calculate Diffuse lighting*/
    vec3 norm = normalize(vertexNormal); // Normalize vectors to 1 unit
    vec3 lightDirection = normalize(lightPos - vertexFragmentPos); // Calculate distance (light direction) between light source and fragments/pixels on cube
    float impact = max(dot(norm, lightDirection), 0.0);// Calculate diffuse impact by generating dot product of normal and light
    vec3 diffuse = impact * lightColor; // Generate diffuse light color

    //Calculate Specular lighting*/
    float specularIntensity = 0.2f; // Set specular light strength
    float highlightSize =  0.5f; // Set specular highlight size
    vec3 viewDir = normalize(viewPosition - vertexFragmentPos); // Calculate view direction
    vec3 reflectDir = reflect(-lightDirection, norm);// Calculate reflection vector
    //Calculate specular component
    float specularComponent = pow(max(dot(viewDir, reflectDir), 0.0), highlightSize);
    vec3 specular = specularIntensity * specularComponent * lightColor;

    // Texture holds the color to be used for all three components
    vec4 textureColor = texture(uTexture, vertexTextureCoordinate * uvScale);

    // Calculate phong result
    vec3 phong = (ambient + diffuse + specular) * textureColor.xyz;

    fragmentColor = vec4(phong, 1.0); // Send lighting results to GPU
}
                                                  );





/* Lamp Shader Source Code*/
const gl4.char* lampVertexShaderSource = gl4.SL(440,

        layout(location = 0) in vec3 position; // VAP position 0 for vertex position data

        out vec3 vertexNormal;

        //Uniform / gl4.obal variables for the  transform matrices
        uniform mat4 model;
        uniform mat4 view;
        uniform mat4 projection;

        void main()
{
    gl4._Position = projection * view * model * vec4(position, 1.0f); // Transforms vertices into clip coordinates
}
                                               );


/* Fragment Shader Source Code*/
const gl4.char* lampFragmentShaderSource = gl4.SL(440,

        out vec4 fragmentColor; // For outgoing lamp color (smaller cube) to the GPU

        void main()
{
    fragmentColor = vec4(1.0f); // Set color to white (1.0f,1.0f,1.0f) with alpha 1.0
}
                                                 );


// Images are loaded with Y axis going down, but Opengl4.'s Y axis goes up, so let's flip it
void flipImageVertically(unsigned char* image, int width, int height, int channels)
{
    for (int j = 0; j < height / 2; ++j)
    {
        int index1 = j * width * channels;
        int index2 = (height - 1 - j) * width * channels;

        for (int i = width * channels; i > 0; --i)
        {
            unsigned char tmp = image[index1];
            image[index1] = image[index2];
            image[index2] = tmp;
            ++index1;
            ++index2;
        }
    }
}


int main(int argc, char* argv[])
{
    if (!UInitialize(argc, argv, &gWindow))
        return EXIT_FAILURE;

    // Create the mesh
    UCreateMesh(gCubeMesh); // Calls the function to create the Vertex Buffer Object

    // Create the shader programs
    if (!UCreateShaderProgram(cubeVertexShaderSource, cubeFragmentShaderSource, gCubeProgramId))
        return EXIT_FAILURE;

    // Load texture
    const char* texFilename = "Silver.jpg";
    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    // tell opengl4. for each sampler to which texture unit it belongs to (only has to be done once)
    gl4.UseProgram(gCubeProgramId);
    // We set the texture as texture unit 0
    gl4.Uniform1i(gl4.GetUniformLocation(gCubeProgramId, "uTexture"), 0);

    UCreateMesh(gCube2Mesh);

    if (!UCreateShaderProgram(cube2VertexShaderSource, cube2FragmentShaderSource, gCube2ProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }

    gl4.UseProgram(gCube2ProgramId);

    gl4.Uniform1i(gl4.GetUniformLocation(gCube2ProgramId, "uTexture"), 0);

    UCreateMesh(gCornerMesh);

    if (!UCreateShaderProgram(cornerVertexShaderSource, cornerFragmentShaderSource, gCornerProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gCornerProgramId);

    gl4.Uniform1i(gl4.GetUniformLocation(gCornerProgramId, "uTexture"), 0);

    UCreateMesh(gBLCornerMesh);

    if (!UCreateShaderProgram(blcornerVertexShaderSource, blcornerFragmentShaderSource, gBLCornerProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gBLCornerProgramId);

    gl4.Uniform1i(gl4.GetUniformLocation(gBLCornerProgramId, "uTexture"), 0);

    UCreateMesh(gFRCornerMesh);

    if (!UCreateShaderProgram(blcornerVertexShaderSource, blcornerFragmentShaderSource, gFRCornerProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gFRCornerProgramId);

    gl4.Uniform1i(gl4.GetUniformLocation(gFRCornerProgramId, "uTexture"), 0);

    UCreateMesh(gFLCornerMesh);

    if (!UCreateShaderProgram(blcornerVertexShaderSource, blcornerFragmentShaderSource, gBLCornerProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gBLCornerProgramId);

    gl4.Uniform1i(gl4.GetUniformLocation(gBLCornerProgramId, "uTexture"), 0);

    UCreateMesh(gTRBoxSupportMesh);

    if (!UCreateShaderProgram(blcornerVertexShaderSource, blcornerFragmentShaderSource, gBLCornerProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gBLCornerProgramId);



    gl4.Uniform1i(gl4.GetUniformLocation(gBLCornerProgramId, "uTexture"), 0);

    //BoxSupport
    UCreateMesh(gTLBoxSupportMesh);

    if (!UCreateShaderProgram(blcornerVertexShaderSource, blcornerFragmentShaderSource, gBLCornerProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gBLCornerProgramId);



    gl4.Uniform1i(gl4.GetUniformLocation(gBLCornerProgramId, "uTexture"), 0);

    UCreateMesh(gBLBoxSupportMesh);

    if (!UCreateShaderProgram(blcornerVertexShaderSource, blcornerFragmentShaderSource, gBLCornerProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gBLCornerProgramId);



    gl4.Uniform1i(gl4.GetUniformLocation(gBLCornerProgramId, "uTexture"), 0);

    UCreateMesh(gBRBoxSupportMesh);

    if (!UCreateShaderProgram(blcornerVertexShaderSource, blcornerFragmentShaderSource, gBLCornerProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gBLCornerProgramId);

    UCreateMesh(gHBoxSupportMesh);

    if (!UCreateShaderProgram(blcornerVertexShaderSource, blcornerFragmentShaderSource, gBLCornerProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gBLCornerProgramId);

    UCreateMesh(gH2BoxSupportMesh);

    if (!UCreateShaderProgram(blcornerVertexShaderSource, blcornerFragmentShaderSource, gBLCornerProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gBLCornerProgramId);



    gl4.Uniform1i(gl4.GetUniformLocation(gBLCornerProgramId, "uTexture"), 0);

    UCreateMesh(gVBoxSupportMesh);

    if (!UCreateShaderProgram(blcornerVertexShaderSource, blcornerFragmentShaderSource, gBLCornerProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gBLCornerProgramId);



    gl4.Uniform1i(gl4.GetUniformLocation(gBLCornerProgramId, "uTexture"), 0);

    UCreateMesh(gPlaneMesh);

    if (!UCreateShaderProgram(planeVertexShaderSource, planeFragmentShaderSource, gPlaneProgramId))
        return EXIT_FAILURE;

    if (!UCreateTexture(texFilename, gTextureId))
    {
        cout << "Failed to load texture " << texFilename << endl;
        return EXIT_FAILURE;
    }
    gl4.UseProgram(gPlaneProgramId);

    gl4.Uniform1i(gl4.GetUniformLocation(gPlaneProgramId, "uTexture"), 0);

    UCreateMesh(gl4.ampMesh);

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gl4.ampProgramId))
        return EXIT_FAILURE;

    gl4.UseProgram(gl4.ampProgramId);

    gl4.Uniform1i(gl4.GetUniformLocation(gl4.ampProgramId, "uTexture"), 0);

    UCreateMesh(gl4.amp2Mesh);

    if (!UCreateShaderProgram(lampVertexShaderSource, lampFragmentShaderSource, gl4.ampProgramId))
        return EXIT_FAILURE;

    gl4.UseProgram(gl4.ampProgramId);

    gl4.Uniform1i(gl4.GetUniformLocation(gl4.ampProgramId, "uTexture"), 0);




    // Sets the background color of the window to black (it will be implicitely used by gl4.Clear)
    gl4.ClearColor(0.0f, 0.0f, 0.0f, 1.0f);

    // render loop
    // -----------
    while (!gl4.fwWindowShouldClose(gWindow))
    {
        // per-frame timing
        // --------------------
        float currentFrame = gl4.fwGetTime();
        gDeltaTime = currentFrame - gl4.astFrame;
        gl4.astFrame = currentFrame;

        // input
        // -----
        UProcessInput(gWindow);

        // Render this frame
        URender();

        gl4.fwPollEvents();
    }

    // Release mesh data
    UDestroyMesh(gCubeMesh);
    UDestroyMesh(gCornerMesh);
    UDestroyMesh(gBLCornerMesh);
    UDestroyMesh(gFLCornerMesh);
    UDestroyMesh(gFRCornerMesh);
    UDestroyMesh(gTRBoxSupportMesh);
    UDestroyMesh(gTLBoxSupportMesh);
    UDestroyMesh(gBLBoxSupportMesh);
    UDestroyMesh(gBRBoxSupportMesh);
    UDestroyMesh(gHBoxSupportMesh);
    UDestroyMesh(gH2BoxSupportMesh);
    UDestroyMesh(gVBoxSupportMesh);
    UDestroyMesh(gPlaneMesh);
    UDestroyMesh(gCube2Mesh);
    UDestroyMesh(gl4.ampMesh);
    UDestroyMesh(gl4.amp2Mesh);

    // Release texture
    UDestroyTexture(gTextureId);

    // Release shader programs
    UDestroyShaderProgram(gCubeProgramId);
    UDestroyShaderProgram(gBLCornerProgramId);
    UDestroyShaderProgram(gCube2ProgramId);
    UDestroyShaderProgram(gCornerProgramId);
    UDestroyShaderProgram(gl4.ampProgramId);
    UDestroyShaderProgram(gPlaneProgramId);

    exit(EXIT_SUCCESS); // Terminates the program successfully
}


// Initialize gl4.FW, gl4.EW, and create a window
bool UInitialize(int argc, char* argv[], gl4.FWwindow** window)
{
    // gl4.FW: initialize and configure
    // ------------------------------
    gl4.fwInit();
    gl4.fwWindowHint(gl4.FW_CONTEXT_VERSION_MAJOR, 4);
    gl4.fwWindowHint(gl4.FW_CONTEXT_VERSION_MINOR, 4);
    gl4.fwWindowHint(gl4.FW_OPENgl4._PROFILE, gl4.FW_OPENgl4._CORE_PROFILE);

#ifdef __APPLE__
    gl4.fwWindowHint(gl4.FW_OPENgl4._FORWARD_COMPAT, gl4._TRUE);
#endif

    // gl4.FW: window creation
    // ---------------------
    * window = gl4.fwCreateWindow(WINDOW_WIDTH, WINDOW_HEIGHT, WINDOW_TITLE, NULL, NULL);
    if (*window == NULL)
    {
        std::cout << "Failed to create gl4.FW window" << std::endl;
        gl4.fwTerminate();
        return false;
    }

    gl4.fwMakeContextCurrent(*window);
    gl4.fwSetFramebufferSizeCallback(*window, UResizeWindow);
    gl4.fwSetCursorPosCallback(*window, UMousePositionCallback);
    gl4.fwSetScrollCallback(*window, UMouseScrollCallback);
    gl4.fwSetMouseButtonCallback(*window, UMouseButtonCallback);

    // tell gl4.FW to capture our mouse
    gl4.fwSetInputMode(*window, gl4.FW_CURSOR, gl4.FW_CURSOR_DISABLED);

    // gl4.EW: initialize
    // ----------------
    // Note: if using gl4.EW version 1.13 or earlier
    gl4.ewExperimental = gl4._TRUE;
    gl4.enum gl4.ewInitResult = gl4.ewInit();

    if (gl4.EW_OK != gl4.ewInitResult)
    {
        std::cerr << gl4.ewGetErrorString(gl4.ewInitResult) << std::endl;
        return false;
    }

    // Displays GPU Opengl4. version
    cout << "INFO: Opengl4. Version: " << gl4.GetString(gl4._VERSION) << endl;

    return true;
}


// process all input: query gl4.FW whether relevant keys are pressed/released this frame and react accordingl4.y
void UProcessInput(gl4.FWwindow* window)
{
    static const float cameraSpeed = 2.5f;

    if (gl4.fwGetKey(window, gl4.FW_KEY_ESCAPE) == gl4.FW_PRESS)
        gl4.fwSetWindowShouldClose(window, true);

    if (gl4.fwGetKey(window, gl4.FW_KEY_W) == gl4.FW_PRESS)
        gCamera.ProcessKeyboard(FORWARD, gDeltaTime);
    if (gl4.fwGetKey(window, gl4.FW_KEY_S) == gl4.FW_PRESS)
        gCamera.ProcessKeyboard(BACKWARD, gDeltaTime);
    if (gl4.fwGetKey(window, gl4.FW_KEY_A) == gl4.FW_PRESS)
        gCamera.ProcessKeyboard(LEFT, gDeltaTime);
    if (gl4.fwGetKey(window, gl4.FW_KEY_D) == gl4.FW_PRESS)
        gCamera.ProcessKeyboard(RIGHT, gDeltaTime);
    if (gl4.fwGetKey(window, gl4.FW_KEY_E) == gl4.FW_PRESS)
        gCamera.ProcessKeyboard(UP, gDeltaTime);
    if (gl4.fwGetKey(window, gl4.FW_KEY_Q) == gl4.FW_PRESS)
        gCamera.ProcessKeyboard(DOWN, gDeltaTime);


    if (gl4.fwGetKey(window, gl4.FW_KEY_1) == gl4.FW_PRESS && gTexWrapMode != gl4._REPEAT)
    {
        gl4.BindTexture(gl4._TEXTURE_2D, gTextureId);
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_WRAP_S, gl4._REPEAT);
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_WRAP_T, gl4._REPEAT);
        gl4.BindTexture(gl4._TEXTURE_2D, 0);

        gTexWrapMode = gl4._REPEAT;

        cout << "Current Texture Wrapping Mode: REPEAT" << endl;
    }
    else if (gl4.fwGetKey(window, gl4.FW_KEY_2) == gl4.FW_PRESS && gTexWrapMode != gl4._MIRRORED_REPEAT)
    {
        gl4.BindTexture(gl4._TEXTURE_2D, gTextureId);
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_WRAP_S, gl4._MIRRORED_REPEAT);
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_WRAP_T, gl4._MIRRORED_REPEAT);
        gl4.BindTexture(gl4._TEXTURE_2D, 0);

        gTexWrapMode = gl4._MIRRORED_REPEAT;

        cout << "Current Texture Wrapping Mode: MIRRORED REPEAT" << endl;
    }
    else if (gl4.fwGetKey(window, gl4.FW_KEY_3) == gl4.FW_PRESS && gTexWrapMode != gl4._CLAMP_TO_EDGE)
    {
        gl4.BindTexture(gl4._TEXTURE_2D, gTextureId);
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_WRAP_S, gl4._CLAMP_TO_EDGE);
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_WRAP_T, gl4._CLAMP_TO_EDGE);
        gl4.BindTexture(gl4._TEXTURE_2D, 0);

        gTexWrapMode = gl4._CLAMP_TO_EDGE;

        cout << "Current Texture Wrapping Mode: CLAMP TO EDGE" << endl;
    }
    else if (gl4.fwGetKey(window, gl4.FW_KEY_4) == gl4.FW_PRESS && gTexWrapMode != gl4._CLAMP_TO_BORDER)
    {
        float color[] = { 1.0f, 0.0f, 1.0f, 1.0f };
        gl4.TexParameterfv(gl4._TEXTURE_2D, gl4._TEXTURE_BORDER_COLOR, color);

        gl4.BindTexture(gl4._TEXTURE_2D, gTextureId);
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_WRAP_S, gl4._CLAMP_TO_BORDER);
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_WRAP_T, gl4._CLAMP_TO_BORDER);
        gl4.BindTexture(gl4._TEXTURE_2D, 0);

        gTexWrapMode = gl4._CLAMP_TO_BORDER;

        cout << "Current Texture Wrapping Mode: CLAMP TO BORDER" << endl;
    }

    if (gl4.fwGetKey(window, gl4.FW_KEY_RIGHT_BRACKET) == gl4.FW_PRESS)
    {
        gUVScale += 0.1f;
        cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" << endl;
    }
    else if (gl4.fwGetKey(window, gl4.FW_KEY_LEFT_BRACKET) == gl4.FW_PRESS)
    {
        gUVScale -= 0.1f;
        cout << "Current scale (" << gUVScale[0] << ", " << gUVScale[1] << ")" << endl;
    }

    // Pause and resume lamp orbiting
    static bool isLKeyDown = false;
    if (gl4.fwGetKey(window, gl4.FW_KEY_L) == gl4.FW_PRESS && !gIsLampOrbiting)
        gIsLampOrbiting = true;
    else if (gl4.fwGetKey(window, gl4.FW_KEY_K) == gl4.FW_PRESS && gIsLampOrbiting)
        gIsLampOrbiting = false;

}


// gl4.fw: whenever the window size changed (by OS or user resize) this callback function executes
void UResizeWindow(gl4.FWwindow* window, int width, int height)
{
    gl4.Viewport(0, 0, width, height);
}


// gl4.fw: whenever the mouse moves, this callback is called
// -------------------------------------------------------
void UMousePositionCallback(gl4.FWwindow* window, double xpos, double ypos)
{
    if (gFirstMouse)
    {
        gl4.astX = xpos;
        gl4.astY = ypos;
        gFirstMouse = false;
    }

    float xoffset = xpos - gl4.astX;
    float yoffset = gl4.astY - ypos; // reversed since y-coordinates go from bottom to top

    gl4.astX = xpos;
    gl4.astY = ypos;

    gCamera.ProcessMouseMovement(xoffset, yoffset);
}


// gl4.fw: whenever the mouse scroll wheel scrolls, this callback is called
// ----------------------------------------------------------------------
void UMouseScrollCallback(gl4.FWwindow* window, double xoffset, double yoffset)
{
    gCamera.ProcessMouseScroll(yoffset);
}

// gl4.fw: handle mouse button events
// --------------------------------
void UMouseButtonCallback(gl4.FWwindow* window, int button, int action, int mods)
{
    switch (button)
    {
    case gl4.FW_MOUSE_BUTTON_LEFT:
    {
        if (action == gl4.FW_PRESS)
            cout << "Left mouse button pressed" << endl;
        else
            cout << "Left mouse button released" << endl;
    }
    break;

    case gl4.FW_MOUSE_BUTTON_MIDDLE:
    {
        if (action == gl4.FW_PRESS)
            cout << "Middle mouse button pressed" << endl;
        else
            cout << "Middle mouse button released" << endl;
    }
    break;

    case gl4.FW_MOUSE_BUTTON_RIGHT:
    {
        if (action == gl4.FW_PRESS)
            cout << "Right mouse button pressed" << endl;
        else
            cout << "Right mouse button released" << endl;
    }
    break;

    default:
        cout << "Unhandled mouse button event" << endl;
        break;
    }
}


// Functioned called to render a frame
void URender()
{
    // Lamp orbits around the origin
    const float angularVelocity = gl4.m::radians(45.0f);
    if (gIsLampOrbiting)
    {
        gl4.m::vec4 newPosition = gl4.m::rotate(angularVelocity * gDeltaTime, gl4.m::vec3(0.0f, 1.0f, 0.0f)) * gl4.m::vec4(gl4.ightPosition, 1.0f);
        gl4.ightPosition.x = newPosition.x;
        gl4.ightPosition.y = newPosition.y;
        gl4.ightPosition.z = newPosition.z;
    }

    // Enable z-depth
    gl4.Enable(gl4._DEPTH_TEST);

    // Clear the frame and z buffers
    gl4.ClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    gl4.Clear(gl4._COLOR_BUFFER_BIT | gl4._DEPTH_BUFFER_BIT);

    // Activate the cube VAO (used by cube and lamp)
    gl4.BindVertexArray(gCubeMesh.vao);
    gl4.BindVertexArray(gFLCornerMesh.vao);
    gl4.BindVertexArray(gFRCornerMesh.vao);
    gl4.BindVertexArray(gCornerMesh.vao);
    gl4.BindVertexArray(gBLCornerMesh.vao);
    gl4.BindVertexArray(gTRBoxSupportMesh.vao);
    gl4.BindVertexArray(gBLBoxSupportMesh.vao);
    gl4.BindVertexArray(gBRBoxSupportMesh.vao);
    gl4.BindVertexArray(gHBoxSupportMesh.vao);
    gl4.BindVertexArray(gH2BoxSupportMesh.vao);
    gl4.BindVertexArray(gVBoxSupportMesh.vao);
    gl4.BindVertexArray(gCube2Mesh.vao);
    gl4.BindVertexArray(gPlaneMesh.vao);
    gl4.BindVertexArray(gl4.ampMesh.vao);
    gl4.BindVertexArray(gl4.amp2Mesh.vao);



    // CUBE: draw cube
    //----------------
    // Set the shader to be used
    gl4.UseProgram(gCubeProgramId);
    gl4.UseProgram(gl4.ampProgramId);
    gl4.UseProgram(gCornerProgramId);
    gl4.UseProgram(gBLCornerProgramId);
    gl4.UseProgram(gCube2ProgramId);
    gl4.UseProgram(gPlaneProgramId);

    // Model matrix: transformations are applied right-to-left order
    gl4.m::mat4 model = gl4.m::translate(gCubePosition) * gl4.m::scale(gCubeScale);

    // camera/view transformation
    gl4.m::mat4 view = gCamera.GetViewMatrix();

    // Creates a perspective projection
    gl4.m::mat4 projection = gl4.m::perspective(gl4.m::radians(gCamera.Zoom), (gl4.float)WINDOW_WIDTH / (gl4.float)WINDOW_HEIGHT, 0.1f, 100.0f);

    // Retrieves and passes transform matrices to the Shader program
    gl4.int modelLoc = gl4.GetUniformLocation(gCubeProgramId, "model");
    gl4.int viewLoc = gl4.GetUniformLocation(gCubeProgramId, "view");
    gl4.int projLoc = gl4.GetUniformLocation(gCubeProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    // Reference matrix uniforms from the Cube Shader program for the cub color, light color, light position, and camera position
    gl4.int objectColorLoc = gl4.GetUniformLocation(gCubeProgramId, "objectColor");
    gl4.int lightColorLoc = gl4.GetUniformLocation(gCubeProgramId, "lightColor");
    gl4.int lightPositionLoc = gl4.GetUniformLocation(gCubeProgramId, "lightPos");
    gl4.int viewPositionLoc = gl4.GetUniformLocation(gCubeProgramId, "viewPosition");




    // Pass color, light, and camera data to the Cube Shader program's corresponding uniforms
    gl4.Uniform3f(objectColorLoc, gObjectColor.r, gObjectColor.g, gObjectColor.b);
    gl4.Uniform3f(lightColorLoc, gl4.ightColor.r, gl4.ightColor.g, gl4.ightColor.b);
    gl4.Uniform3f(lightPositionLoc, gl4.ightPosition.x, gl4.ightPosition.y, gl4.ightPosition.z);
    const gl4.m::vec3 cameraPosition = gCamera.Position;
    gl4.Uniform3f(viewPositionLoc, cameraPosition.x, cameraPosition.y, cameraPosition.z);

    gl4.int UVScaleLoc = gl4.GetUniformLocation(gCubeProgramId, "uvScale");
    gl4.int UVScaleLoc1 = gl4.GetUniformLocation(gPlaneProgramId, "uvScale");
    gl4.Uniform2fv(UVScaleLoc, 1, gl4.m::value_ptr(gUVScale));

    // bind textures on corresponding texture units
    gl4.ActiveTexture(gl4._TEXTURE0);
    gl4.BindTexture(gl4._TEXTURE_2D, gTextureId);

    // Draws the triangl4.es
    gl4.DrawArrays(gl4._TRIANgl4.ES, 42, 36);

    //draw Corner

    model = gl4.m::translate(gCornerPosition) * gl4.m::scale(gCornerScale);

    modelLoc = gl4.GetUniformLocation(gCornerProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gCornerProgramId, "view");
    projLoc = gl4.GetUniformLocation(gCornerProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 114, 24);

    //draw Corner

    model = gl4.m::translate(gBLCornerPosition) * gl4.m::scale(gBLCornerScale);

    modelLoc = gl4.GetUniformLocation(gBLCornerProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gBLCornerProgramId, "view");
    projLoc = gl4.GetUniformLocation(gBLCornerProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 114, 24);

    //draw Corner

    model = gl4.m::translate(gFLCornerPosition) * gl4.m::scale(gFLCornerScale);

    modelLoc = gl4.GetUniformLocation(gBLCornerProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gBLCornerProgramId, "view");
    projLoc = gl4.GetUniformLocation(gBLCornerProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 114, 24);

    //draw Corner

    model = gl4.m::translate(gFRCornerPosition) * gl4.m::scale(gFRCornerScale);

    modelLoc = gl4.GetUniformLocation(gBLCornerProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gBLCornerProgramId, "view");
    projLoc = gl4.GetUniformLocation(gBLCornerProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 114, 24);

    //BoxSupport

    model = gl4.m::translate(gTRBoxSupportPosition) * gl4.m::scale(gTRBoxSupportScale);

    modelLoc = gl4.GetUniformLocation(gBLCornerProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gBLCornerProgramId, "view");
    projLoc = gl4.GetUniformLocation(gBLCornerProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 138, 30);

    //BoxSupport

    model = gl4.m::translate(gTLBoxSupportPosition) * gl4.m::scale(gTLBoxSupportScale);

    modelLoc = gl4.GetUniformLocation(gBLCornerProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gBLCornerProgramId, "view");
    projLoc = gl4.GetUniformLocation(gBLCornerProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 138, 30);

    model = gl4.m::translate(gBLBoxSupportPosition) * gl4.m::scale(gBLBoxSupportScale);

    modelLoc = gl4.GetUniformLocation(gBLCornerProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gBLCornerProgramId, "view");
    projLoc = gl4.GetUniformLocation(gBLCornerProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 138, 30);

    model = gl4.m::translate(gBRBoxSupportPosition) * gl4.m::scale(gBRBoxSupportScale);

    modelLoc = gl4.GetUniformLocation(gBLCornerProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gBLCornerProgramId, "view");
    projLoc = gl4.GetUniformLocation(gBLCornerProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 138, 30);

    //Horizontal Box Support

    model = gl4.m::translate(gHBoxSupportPosition) * gl4.m::scale(gHBoxSupportScale);

    modelLoc = gl4.GetUniformLocation(gBLCornerProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gBLCornerProgramId, "view");
    projLoc = gl4.GetUniformLocation(gBLCornerProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 168, 36);

    //Bottom Horizontal Support

    model = gl4.m::translate(gH2BoxSupportPosition) * gl4.m::scale(gH2BoxSupportScale);

    modelLoc = gl4.GetUniformLocation(gBLCornerProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gBLCornerProgramId, "view");
    projLoc = gl4.GetUniformLocation(gBLCornerProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 168, 36);

    model = gl4.m::translate(gVBoxSupportPosition) * gl4.m::scale(gVBoxSupportScale);

    modelLoc = gl4.GetUniformLocation(gBLCornerProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gBLCornerProgramId, "view");
    projLoc = gl4.GetUniformLocation(gBLCornerProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 204, 36);



    //CUBE2: draw Cube2

    model = gl4.m::translate(gCubePosition2) * gl4.m::scale(gCubeScale2);

    modelLoc = gl4.GetUniformLocation(gCube2ProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gCube2ProgramId, "view");
    projLoc = gl4.GetUniformLocation(gCube2ProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 78, 36);



    //PLANE: draw plane

    gl4.UseProgram(gPlaneProgramId);

    // Model matrix: transformations are applied right-to-left order
    model = gl4.m::translate(gPlanePosition) * gl4.m::scale(gPlaneScale);

    modelLoc = gl4.GetUniformLocation(gPlaneProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gPlaneProgramId, "view");
    projLoc = gl4.GetUniformLocation(gPlaneProgramId, "projection");

    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 36, 6);




    // LAMP: draw lamp
    //----------------
    gl4.UseProgram(gl4.ampProgramId);

    //Transform the smaller cube used as a visual que for the light source
    model = gl4.m::translate(gl4.ightPosition) * gl4.m::scale(gl4.ightScale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = gl4.GetUniformLocation(gl4.ampProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gl4.ampProgramId, "view");
    projLoc = gl4.GetUniformLocation(gl4.ampProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 0, 30);

    // LAMP2: draw lamp
//----------------
    gl4.UseProgram(gl4.ampProgramId);

    //Transform the smaller cube used as a visual que for the light source
    model = gl4.m::translate(gl4.ight2Position) * gl4.m::scale(gl4.ight2Scale);

    // Reference matrix uniforms from the Lamp Shader program
    modelLoc = gl4.GetUniformLocation(gl4.ampProgramId, "model");
    viewLoc = gl4.GetUniformLocation(gl4.ampProgramId, "view");
    projLoc = gl4.GetUniformLocation(gl4.ampProgramId, "projection");

    // Pass matrix data to the Lamp Shader program's matrix uniforms
    gl4.UniformMatrix4fv(modelLoc, 1, gl4._FALSE, gl4.m::value_ptr(model));
    gl4.UniformMatrix4fv(viewLoc, 1, gl4._FALSE, gl4.m::value_ptr(view));
    gl4.UniformMatrix4fv(projLoc, 1, gl4._FALSE, gl4.m::value_ptr(projection));

    gl4.DrawArrays(gl4._TRIANgl4.ES, 0, 36);

    // Deactivate the Vertex Array Object and shader program
    gl4.BindVertexArray(0);
    gl4.UseProgram(0);

    // gl4.fw: swap buffers and poll IO events (keys pressed/released, mouse moved etc.)
    gl4.fwSwapBuffers(gWindow);    // Flips the the back buffer with the front buffer every frame.
}


// Implements the UCreateMesh function
void UCreateMesh(gl4.Mesh& mesh)
{
    // Position and Color data
    gl4.float verts[] = {
        //Positions          //Normals
        // ------------------------------------------------------
        //Back Face          //Negative Z Normal  Texture Coords.
        -0.25f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f, //0
        0.25f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 0.0f, //1
        0.25f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f, //2
        0.25f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  1.0f, 1.0f, //3
        -0.25f,  0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 1.0f, //4
        -0.25f, -0.5f, -0.5f,  0.0f,  0.0f, -1.0f,  0.0f, 0.0f, //5

        //Front Face         //Positive Z Normal
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f, //6
        0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f, //7
        0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f, //8
        0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f, //9
        -0.5f,  0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f, //10
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f, //11

        //Left Face          //Negative X Normal
        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,  //12
        -0.5f,  0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f,  //13
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,  //14
        -0.5f, -0.5f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f,  //15
        -0.5f, -0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f,  //16
        -0.5f,  0.5f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f,  //17

        //Right Face         //Positive X Normal
        0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,  //18
        0.5f,  0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f,  //19
        0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,  //20
        0.5f, -0.5f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f,  //21
        0.5f, -0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f,  //22
        0.5f,  0.5f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f,  //23

        //Bottom Face        //Negative Y Normal
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f,  0.0f,  0.0f, 1.0f,  //24
        0.5f, -0.5f, -0.5f,  0.0f,  0.0f,  0.0f,  1.0f, 1.0f,  //25
        0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  0.0f,  1.0f, 0.0f,  //26
        0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  0.0f,  1.0f, 0.0f,  //27
        -0.5f, -0.5f,  0.5f,  0.0f,  0.0f,  0.0f,  0.0f, 0.0f,  //28
        -0.5f, -0.5f, -0.5f,  0.0f,  0.0f,  0.0f,  0.0f, 1.0f,  //29

        //Top Face           //Positive Y Normal
        0.0f,  0.0f, -0.5f, 0.0f,  1.0f,  0.0f,  0.0f, 0.0f,   //30
        0.0f,  0.5f, -0.5f, 0.0f,  1.0f,  0.0f,  0.0f, 1.0f,   //31
        0.0f,  0.5f,  0.5f, 0.0f,  1.0f,  0.0f,  1.0f, 0.0f,   //32
        0.0f,  0.5f,  0.5f, 0.0f,  1.0f,  0.0f,  0.0f, 0.0f,   //33
        0.0f,  0.0f,  0.5f, 0.0f,  1.0f,  0.0f,  0.0f, 0.0f,   //34
        0.0f,  0.5f, -0.5f, 0.0f,  1.0f,  0.0f,  0.0f, 0.0f,   //35

        //plane

        -0.5f, -0.5f, -0.5f,  1.0f,  1.0f,  1.0f,  0.0f, 0.0f, //36
        0.5f, -0.5f, -0.5f,  1.0f,  1.0f,  1.0f,  0.0f, 0.0f, //37
        0.5f, -0.5f,  0.5f,  1.0f,  1.0f,  1.0f,  0.0f, 0.0f, //38
        0.5f, -0.5f,  0.5f,  1.0f,  1.0f,  1.0f,  0.0f, 0.0f, //39
        -0.5f, -0.5f,  0.5f,  1.0f,  1.0f,  1.0f,  0.0f, 0.0f, //40
        -0.5f, -0.5f, -0.5f,  1.0f,  1.0f,  1.0f,  0.0f, 0.0f, //41

        //top aluminum

        -1.5f, -0.05f, -0.5f,  0.0f,  1.0f,  1.0f,  0.0f, 0.0f, //42
        1.5f, -0.05f, -0.5f,  0.0f,  1.0f,  1.0f,  1.0f, 0.0f, //43
        1.5f,  0.05f, -0.5f,  0.0f,  1.0f,  1.0f,  1.0f, 1.0f, //44
        1.5f,  0.05f, -0.5f,  0.0f,  1.0f,  1.0f,  1.0f, 1.0f, //45
        -1.5f,  0.05f, -0.5f,  0.0f,  1.0f,  1.0f,  0.0f, 1.0f, //46
        -1.5f, -0.05f, -0.5f,  0.0f,  1.0f,  1.0f,  0.0f, 0.0f, //47

        //Front Face         //Positive Z Normal
        -1.5f, -0.05f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f, //48
        1.5f, -0.05f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 0.0f, //49
        1.5f,  0.05f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f, //50
        1.5f,  0.05f,  0.5f,  0.0f,  0.0f,  1.0f,  1.0f, 1.0f, //51
        -1.5f,  0.05f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 1.0f, //52
        -1.5f, -0.05f,  0.5f,  0.0f,  0.0f,  1.0f,  0.0f, 0.0f, //53

        //Left Face          //Negative X Normal
        -1.5f,  0.05f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f, //54
        -1.5f,  0.05f, -0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 1.0f, //55
        -1.5f, -0.05f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f, //56
        -1.5f, -0.05f, -0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 1.0f, //57
        -1.5f, -0.05f,  0.5f, -1.0f,  0.0f,  0.0f,  0.0f, 0.0f, //58
        -1.5f,  0.05f,  0.5f, -1.0f,  0.0f,  0.0f,  1.0f, 0.0f, //59

        //Right Face         //Positive X Normal
        1.5f,  0.05f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f, //60
        1.5f,  0.05f, -0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 1.0f, //61
        1.5f, -0.05f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f, //62
        1.5f, -0.05f, -0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 1.0f, //63
        1.5f, -0.05f,  0.5f,  1.0f,  0.0f,  0.0f,  0.0f, 0.0f, //64
        1.5f,  0.05f,  0.5f,  1.0f,  0.0f,  0.0f,  1.0f, 0.0f, //65

        //Bottom Face        //Negative Y Normal
        -1.5f, -0.05f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f, //66
        1.5f, -0.05f, -0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 1.0f, //67
        1.5f, -0.05f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f, //68
        1.5f, -0.05f,  0.5f,  0.0f, -1.0f,  0.0f,  1.0f, 0.0f, //69
        -1.5f, -0.05f,  0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 0.0f, //70
        -1.5f, -0.05f, -0.5f,  0.0f, -1.0f,  0.0f,  0.0f, 1.0f, //71

        //Top Face           //Positive Y Normal
        -1.5f,  0.05f, -0.5f,  1.0f,  0.0f,   1.0f,  0.0f, 0.0f, //72
        1.5f,  0.05f, -0.5f,  1.0f,  0.0f,   1.0f,  1.0f, 0.0f, //73
        1.5f,  0.05f,  0.5f,  1.0f,  0.0f,   1.0f,  1.0f, 1.0f, //74
        1.5f,  0.05f,  0.5f,  1.0f,  0.0f,   1.0f,  0.0f, 1.0f, //75
        -1.5f,  0.05f,  0.5f,  1.0f,  0.0f,   1.0f,  1.0f, 0.0f, //76
        -1.5f,  0.05f, -0.5f,  1.0f,  0.0f,   1.0f,  0.0f, 0.0f, //77

        //bottom aluminum

        -1.5f, -0.05f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,    //78
        1.5f, -0.05f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f,    //79
        1.5f,  0.05f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,    //80
        1.5f,  0.05f, -0.5f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f,    //81
        -1.5f,  0.05f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f,    //82
        -1.5f, -0.05f, -0.5f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f,    //83

        //Front Face         //Positive Z Normal
        -1.5f, -0.05f, 0.5f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,      //84
        1.5f, -0.05f, 0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f,      //85
        1.5f,  0.05f, 0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,      //86
        1.5f,  0.05f, 0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,      //87
        -1.5f,  0.05f, 0.5f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f,      //88
        -1.5f, -0.05f, 0.5f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,      //89

        //Left Face          //Negative X Normal
        -1.5f,  0.05f,  0.5f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f,   //90
        -1.5f,  0.05f, -0.5f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f,   //91
        -1.5f, -0.05f, -0.5f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f,   //92
        -1.5f, -0.05f, -0.5f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f,   //93
        -1.5f, -0.05f,  0.5f, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f,   //94
        -1.5f,  0.05f,  0.5f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f,   //95

        //Right Face         //Positive X Normal
        1.5f,  0.05f,  0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,     //96
        1.5f,  0.05f, -0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f,     //97
        1.5f, -0.05f, -0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,     //98
        1.5f, -0.05f, -0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,     //99
        1.5f, -0.05f,  0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f,     //100
        1.5f,  0.05f,  0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,     //101

        //Bottom Face        //Negative Y Normal
        -1.5f, -0.05f, -0.5f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f,    //102
        1.5f, -0.05f, -0.5f, 0.0f, -1.0f, 0.0f, 1.0f, 1.0f,    //103
        1.5f, -0.05f,  0.5f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,    //104
        1.5f, -0.05f,  0.5f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,    //105
        -1.5f, -0.05f,  0.5f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f,    //106
        -1.5f, -0.05f, -0.5f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f,    //107

        //Top Face           //Positive Y Normal
        -1.5f, 0.05f, -0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f,     //108
        1.5f, 0.05f, -0.5f, 0.0f, 0.0f, 0.0f, 1.0f, 1.0f,     //109
        1.5f, 0.05f, 0.5f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f,      //110
        1.5f, 0.05f, 0.5f, 0.0f, 0.0f, 0.0f, 1.0f, 0.0f,      //111
        -1.5f, 0.05f, 0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 0.0f,      //112
        -1.5f, 0.05f, -0.5f, 0.0f, 0.0f, 0.0f, 0.0f, 1.0f,      //113

        //Back Right Corner

        1.5f,  0.5f, -0.25f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,     //114
        1.5f,  0.5f, -0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f,     //115
        1.5f, -2.5f, -0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,     //116
        1.5f, -2.5f, -0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,     //117
        1.5f, -2.5f, -0.25f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f,     //118
        1.5f,  0.5f, -0.25f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,     //119

        1.25f, 0.5f, -0.25f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,     //120
        1.25f, 0.5f, -0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f,     //121
        1.25f, -2.5f, -0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,     //122
        1.25f, -2.5f, -0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f,     //123
        1.25f, -2.5f, -0.25f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f,     //124
        1.25f, 0.5f, -0.25f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f,     //125

        1.25f, -2.5f, -0.5f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,      //126
        1.5f, -2.5f, -0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f,      //127
        1.5f, 0.5f, -0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,      //128
        1.5f, 0.5f, -0.5f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,      //129
        1.25f, 0.5f, -0.5f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f,      //130
        1.25f, -2.5f, -0.5f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,       //131

        1.25f, -2.5f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,      //132
        1.5f, -2.5f, -0.25f, 0.0f, 0.0f, 1.0f, 1.0f, 0.0f,      //133
        1.5f, 0.5f, -0.25f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,      //134
        1.5f, 0.5f, -0.25f, 0.0f, 0.0f, 1.0f, 1.0f, 1.0f,      //135
        1.25f, 0.5f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f, 1.0f,      //136
        1.25f, -2.5f, -0.25f, 0.0f, 0.0f, 1.0f, 0.0f, 0.0f,      //137


        1.25f, -0.5f, -0.25f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, //38
        1.5f, -0.5f, -0.25f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, //39
        1.5f, -0.5f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f, //40
        1.5f, -0.5f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, //41
        1.25f, -0.5f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, //42
        1.25f, -0.5f, -0.25f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, //43

        1.25f,  -0.75f, -0.25f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, //44
        1.5f, -0.75f, -0.25f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, //45
        1.5f, -0.75f, 1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 1.0f, //46
        1.5f, -0.75f, 1.0f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f, //47
        1.25f, -0.75f, 1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, //48
        1.25f, -0.75f, -0.25f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, //49

        1.25f, -0.5f, -0.25f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, //50
        1.25f, -0.5f,  1.00f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, //51
        1.25f, -0.75f, 1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 1.0f, //52
        1.25f, -0.75f, 1.0f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f, //53
        1.25f, -0.75f, -0.25f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, //54
        1.25f, -0.5f, -0.25f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, //55

        1.5f, -0.5f, -0.25f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, //56
        1.5f, -0.5f, 1.00f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, //57
        1.5f, -0.75f, 1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 1.0f, //58
        1.5f, -0.75f, 1.0f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f, //59
        1.5f, -0.75f, -0.25f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, //60
        1.5f, -0.5f, -0.25f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, //61

        1.5f, -0.5f, 1.0f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f,    //62
        1.5f, -0.75f, 1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,  //63
        1.25f, -0.75f, 1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,  //64
        1.25f, -0.5f, 1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,   //65
        1.25f, -0.75f, 1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,  //66
        1.5f, -0.5f, 1.0f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f,    //67

        -0.5f, -0.5f, 1.0f, 0.0f,  1.0f, 1.0f, 0.0f, 0.0f,    //68
        2.5f, -0.75f, 1.0f, 0.0f,  1.0f, 1.0f, 1.0f, 0.0f,  //69
        -0.5f, -0.75f, 1.0f, 0.0f,  1.0f, 1.0f, 1.0f, 0.0f,  //70
        2.5f, -0.5f, 1.0f, 0.0f,  1.0f, 1.0f, 1.0f, 0.0f,   //71
        2.5f, -0.75f, 1.0f, 0.0f,  1.0f, 1.0f, 1.0f, 0.0f,  //72
        -0.5f, -0.5f, 1.0f, 0.0f,  1.0f, 1.0f, 1.0f, 0.0f,    //73

        -0.5f, -0.5f,  0.75f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,    //74
        2.5f, -0.75f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,  //75
        -0.5f, -0.75f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,  //76
        2.5f, -0.5f,  0.75f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,   //78
        2.5f, -0.75f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,  //79
        -0.5f, -0.5f,  0.75f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,    //80

        -0.5f, -0.5f,  1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,    //81
        2.5f, -0.5f,  1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,  //82
        -0.5f, -0.5f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,  //83
        -0.5f, -0.5f, 0.75f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,   //84
        2.5f, -0.5f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,  //85
        2.5f, -0.5f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,    //86

        -0.5f, -0.75f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,    //87
        2.5f, -0.75f, 1.0f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,  //88
        -0.5f, -0.75f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,  //89
        -0.5f, -0.75f, 0.75f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,   //90
        2.5f, -0.75f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,  //91
        2.5f, -0.75f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,   //92

        -0.5f, -0.75f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,    //93
        -0.5f, -0.75f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,  //94
        -0.5f, -0.5f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,  //95
        -0.5f, -0.5f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,   //96
        -0.5f, -0.5f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,  //97
        -0.5f, -0.75f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,   //98

        2.5f, -0.75f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,    //99
        2.5f, -0.75f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,  //200
        2.5f, -0.5f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f,  //201
        2.5f, -0.5f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,   //202
        2.5f, -0.5f, 0.75f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f,  //203
        2.5f, -0.75f, 1.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f,    //204

        //Electric Panel
        //back
        -0.5f, -0.5f,  0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f, //42
        0.5f, -0.5f,  0.0f, 0.0f, 0.0f, -1.0f, 1.0f, 0.0f, //43
        0.5f, 0.25f,  0.0f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f, //44
        0.5f, 0.25f,  0.0f, 0.0f, 0.0f, -1.0f, 1.0f, 1.0f, //45
        -0.5f, 0.25f,  0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 1.0f, //46
        -0.5f, -0.5f,  0.0f, 0.0f, 0.0f, -1.0f, 0.0f, 0.0f, //47

        //Front Face         //Positive Z Normal
        -0.5f, -0.5f, 0.5f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, //48
        0.5f, -0.5f, 0.5f, 0.0f, 1.0f, 1.0f, 1.0f, 0.0f, //49
        0.5f, 0.25f, 0.5f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, //50
        0.5f, 0.25f, 0.5f, 0.0f, 1.0f, 1.0f, 1.0f, 1.0f, //51
        -0.5f, 0.25f, 0.5f, 0.0f, 1.0f, 1.0f, 0.0f, 1.0f, //52
        -0.5f, -0.5f, 0.5f, 0.0f, 1.0f, 1.0f, 0.0f, 0.0f, //53

        //Left Face          //Negative X Normal
        -0.5f, 0.25f, 0.5f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, //54
        -0.5f, 0.25f,  0.0f, -1.0f, 0.0f, 0.0f, 1.0f, 1.0f, //55
        -0.5f, -0.5f,  0.0f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, //56
        -0.5f, -0.5f,  0.0f, -1.0f, 0.0f, 0.0f, 0.0f, 1.0f, //57
        -0.5f, -0.5f, 0.5f, -1.0f, 0.0f, 0.0f, 0.0f, 0.0f, //58
        -0.5f, 0.25f, 0.5f, -1.0f, 0.0f, 0.0f, 1.0f, 0.0f, //59

        //Right Face         //Positive X Normal
        0.5f, 0.25f, 0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, //60
        0.5f, 0.25f,  0.0f, 1.0f, 0.0f, 0.0f, 1.0f, 1.0f, //61
        0.5f, -0.5f,  0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, //62
        0.5f, -0.5f,  0.0f, 1.0f, 0.0f, 0.0f, 0.0f, 1.0f, //63
        0.5f, -0.5f, 0.5f, 1.0f, 0.0f, 0.0f, 0.0f, 0.0f, //64
        0.5f, 0.25f, 0.5f, 1.0f, 0.0f, 0.0f, 1.0f, 0.0f, //65

        //Bottom Face        //Negative Y Normal
        -0.5f, -0.5f,  0.0f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f, //66
        0.5f, -0.5f,  0.0f, 0.0f, -1.0f, 0.0f, 1.0f, 1.0f, //67
        0.5f, -0.5f, 0.5f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, //68
        0.5f, -0.5f, 0.5f, 0.0f, -1.0f, 0.0f, 1.0f, 0.0f, //69
        -0.5f, -0.5f, 0.5f, 0.0f, -1.0f, 0.0f, 0.0f, 0.0f, //70
        -0.5f, -0.5f,  0.0f, 0.0f, -1.0f, 0.0f, 0.0f, 1.0f, //71

        //Top Face           //Positive Y Normal
        -0.5f, 0.25f,  0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f, //72
        0.5f, 0.25f,  0.0f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, //73
        0.5f, 0.25f, 0.5f, 0.0f, 1.0f, 0.0f, 1.0f, 1.0f, //74
        0.5f, 0.25f, 0.5f, 0.0f, 1.0f, 0.0f, 0.0f, 1.0f, //75
        -0.5f, 0.25f, 0.5f, 0.0f, 1.0f, 0.0f, 1.0f, 0.0f, //76
        -0.5f, 0.25f,  0.0f, 0.0f, 1.0f, 0.0f, 0.0f, 0.0f //77







    };

    const gl4.uint floatsPerVertex = 3;
    const gl4.uint floatsPerNormal = 3;
    const gl4.uint floatsPerUV = 2;

    mesh.nVertices = sizeof(verts) / (sizeof(verts[0]) * (floatsPerVertex + floatsPerNormal + floatsPerUV));

    gl4.GenVertexArrays(1, &mesh.vao); // we can also generate multiple VAOs or buffers at the same time
    gl4.BindVertexArray(mesh.vao);


    // Create 2 buffers: first one for the vertex data; second one for the indices
    gl4.GenBuffers(1, &mesh.vbo);
    gl4.BindBuffer(gl4._ARRAY_BUFFER, mesh.vbo); // Activates the buffer
    gl4.BufferData(gl4._ARRAY_BUFFER, sizeof(verts), verts, gl4._STATIC_DRAW); // Sends vertex or coordinate data to the GPU




    // Strides between vertex coordinates is 6 (x, y, z, r, g, b, a). A tightly packed stride is 0.
    gl4.int stride = sizeof(float) * (floatsPerVertex + floatsPerNormal + floatsPerUV);// The number of floats before each

    // Create Vertex Attribute Pointers
    gl4.VertexAttribPointer(0, floatsPerVertex, gl4._FLOAT, gl4._FALSE, stride, 0);
    gl4.EnableVertexAttribArray(0);

    gl4.VertexAttribPointer(1, floatsPerNormal, gl4._FLOAT, gl4._FALSE, stride, (void*)(sizeof(float) * floatsPerVertex));
    gl4.EnableVertexAttribArray(1);

    gl4.VertexAttribPointer(2, floatsPerUV, gl4._FLOAT, gl4._FALSE, stride, (void*)(sizeof(float) * (floatsPerVertex + floatsPerNormal)));
    gl4.EnableVertexAttribArray(2);
}


void UDestroyMesh(gl4.Mesh& mesh)
{
    gl4.DeleteVertexArrays(1, &mesh.vao);
    gl4.DeleteBuffers(1, &mesh.vbo);
}


/*Generate and load the texture*/
bool UCreateTexture(const char* filename, gl4.uint& textureId)
{
    int width, height, channels;
    unsigned char* image = stbi_load(filename, &width, &height, &channels, 0);
    if (image)
    {
        flipImageVertically(image, width, height, channels);

        gl4.GenTextures(1, &textureId);
        gl4.BindTexture(gl4._TEXTURE_2D, textureId);

        // set the texture wrapping parameters
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_WRAP_S, gl4._REPEAT);
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_WRAP_T, gl4._REPEAT);
        // set texture filtering parameters
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_MIN_FILTER, gl4._LINEAR);
        gl4.TexParameteri(gl4._TEXTURE_2D, gl4._TEXTURE_MAG_FILTER, gl4._LINEAR);

        if (channels == 3)
            gl4.TexImage2D(gl4._TEXTURE_2D, 0, gl4._RGB8, width, height, 0, gl4._RGB, gl4._UNSIGNED_BYTE, image);
        else if (channels == 4)
            gl4.TexImage2D(gl4._TEXTURE_2D, 0, gl4._RGBA8, width, height, 0, gl4._RGBA, gl4._UNSIGNED_BYTE, image);
        else
        {
            cout << "Not implemented to handle image with " << channels << " channels" << endl;
            return false;
        }

        gl4.GenerateMipmap(gl4._TEXTURE_2D);

        stbi_image_free(image);
        gl4.BindTexture(gl4._TEXTURE_2D, 0); // Unbind the texture

        return true;
    }

    // Error loading the image
    return false;
}


void UDestroyTexture(gl4.uint textureId)
{
    gl4.GenTextures(1, &textureId);
}


// Implements the UCreateShaders function
bool UCreateShaderProgram(const char* vtxShaderSource, const char* fragShaderSource, gl4.uint& programId)
{
    // Compilation and linkage error reporting
    int success = 0;
    char infoLog[512];

    // Create a Shader program object.
    programId = gl4.CreateProgram();

    // Create the vertex and fragment shader objects
    gl4.uint vertexShaderId = gl4.CreateShader(gl4._VERTEX_SHADER);
    gl4.uint fragmentShaderId = gl4.CreateShader(gl4._FRAGMENT_SHADER);

    // Retrive the shader source
    gl4.ShaderSource(vertexShaderId, 1, &vtxShaderSource, NULL);
    gl4.ShaderSource(fragmentShaderId, 1, &fragShaderSource, NULL);

    // Compile the vertex shader, and print compilation errors (if any)
    gl4.CompileShader(vertexShaderId); // compile the vertex shader
    // check for shader compile errors
    gl4.GetShaderiv(vertexShaderId, gl4._COMPILE_STATUS, &success);
    if (!success)
    {
        gl4.GetShaderInfoLog(vertexShaderId, 512, NULL, infoLog);
        std::cout << "ERROR::SHADER::VERTEX::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    gl4.CompileShader(fragmentShaderId); // compile the fragment shader
    // check for shader compile errors
    gl4.GetShaderiv(fragmentShaderId, gl4._COMPILE_STATUS, &success);
    if (!success)
    {
        gl4.GetShaderInfoLog(fragmentShaderId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::FRAGMENT::COMPILATION_FAILED\n" << infoLog << std::endl;

        return false;
    }

    // Attached compiled shaders to the shader program
    gl4.AttachShader(programId, vertexShaderId);
    gl4.AttachShader(programId, fragmentShaderId);

    gl4.LinkProgram(programId);   // links the shader program
    // check for linking errors
    gl4.GetProgramiv(programId, gl4._LINK_STATUS, &success);
    if (!success)
    {
        gl4.GetProgramInfoLog(programId, sizeof(infoLog), NULL, infoLog);
        std::cout << "ERROR::SHADER::PROGRAM::LINKING_FAILED\n" << infoLog << std::endl;

        return false;
    }

    gl4.UseProgram(programId);    // Uses the shader program

    return true;
}


void UDestroyShaderProgram(gl4.uint programId)
{
    gl4.DeleteProgram(programId);
}